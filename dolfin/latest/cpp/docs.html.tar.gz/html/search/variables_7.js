var searchData=
[
  ['geometry',['geometry',['../d4/d43/classdolfin_1_1LocalMeshData.html#a00d1099ef781976ca8c7986b2724bcd9',1,'dolfin::LocalMeshData']]],
  ['global_5fcell_5findices',['global_cell_indices',['../d8/d12/structdolfin_1_1LocalMeshData_1_1Topology.html#a285692b4e6e148d3519f6c86f48a2f4c',1,'dolfin::LocalMeshData::Topology']]],
  ['goal',['goal',['../d0/d1c/classdolfin_1_1GenericAdaptiveVariationalSolver.html#a22b561e6763c75deceb4ef0d4b9dc8df',1,'dolfin::GenericAdaptiveVariationalSolver']]]
];
