var searchData=
[
  ['quadrature_5frules_5fcut_5fcells',['quadrature_rules_cut_cells',['../da/d83/classdolfin_1_1MultiMesh.html#ad027cfd5f901f97cbbe9f677d0622321',1,'dolfin::MultiMesh::quadrature_rules_cut_cells(std::size_t part) const'],['../da/d83/classdolfin_1_1MultiMesh.html#ade56592f4de4111b64cfc43e5ba1127f',1,'dolfin::MultiMesh::quadrature_rules_cut_cells(std::size_t part, unsigned int cell_index) const']]],
  ['quadrature_5frules_5finterface',['quadrature_rules_interface',['../da/d83/classdolfin_1_1MultiMesh.html#abcecf36255acc65a30d3624ee467e081',1,'dolfin::MultiMesh::quadrature_rules_interface(std::size_t part) const'],['../da/d83/classdolfin_1_1MultiMesh.html#a5fb8966406b330106b19383edd01b012',1,'dolfin::MultiMesh::quadrature_rules_interface(std::size_t part, unsigned int cell_index) const']]],
  ['quadrature_5frules_5foverlap',['quadrature_rules_overlap',['../da/d83/classdolfin_1_1MultiMesh.html#ad484f077f13aa3219a617deb5c88431e',1,'dolfin::MultiMesh::quadrature_rules_overlap(std::size_t part) const'],['../da/d83/classdolfin_1_1MultiMesh.html#ad94e4beda77167d4798efaa27801d728',1,'dolfin::MultiMesh::quadrature_rules_overlap(std::size_t part, unsigned int cell) const']]],
  ['quadrilateralcell',['QuadrilateralCell',['../da/d42/classdolfin_1_1QuadrilateralCell.html#a0e61916c75adc7c12f57f1097a67364d',1,'dolfin::QuadrilateralCell']]]
];
