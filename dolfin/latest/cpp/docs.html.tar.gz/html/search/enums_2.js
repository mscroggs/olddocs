var searchData=
[
  ['ghosts',['Ghosts',['../df/dc9/classdolfin_1_1TensorLayout.html#ac803c31f2299f93c0fa6fc4a47085ae3',1,'dolfin::TensorLayout']]]
];
